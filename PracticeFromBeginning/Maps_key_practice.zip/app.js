var http = require('http')
var fs = require('fs')

var server = http.createServer(function(req,res){
    console.log('request was made : ',req.url)
    res.writeHead(200,{'Content-Type':'text/html'})
    var myReadSteam = fs.createReadStream(__dirname+'/map.html','utf8')
    myReadSteam.pipe(res);
});

server.listen(8888,'127.0.0.1');
console.log("now listing to port 8888")