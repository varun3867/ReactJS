import React, {Component} from 'react';
import classes from '../common/common.css';

class History extends Component{

    render(){
        return(

            <div className={classes.ArrangeDashboard}>

            Under Construction !!!

            </div>
        )
    }
}
    
export default History;