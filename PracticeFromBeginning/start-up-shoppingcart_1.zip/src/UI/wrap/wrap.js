const wrap = (props) => props.children

export default wrap; 