import React from 'react'
import SelectionBox from './SelectionBox';


function BrowseItems() {
    return (
        <div>
          
            <SelectionBox/>
          
        </div>
      )
}

export default  BrowseItems;
