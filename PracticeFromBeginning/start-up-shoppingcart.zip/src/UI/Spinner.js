import React from 'react';
import './Spinner.css';


const spinner = () => (
    <div className="loader">Loading...</div>
);

export default spinner;