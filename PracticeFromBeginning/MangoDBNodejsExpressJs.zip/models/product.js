const mongoose = require('mongoose')

const productSchema=new mongoose.Schema({
    name:{type:String,requiore:true},
    price:{type:String,require:true}
})

module.exports = mongoose.model('Product',productSchema)