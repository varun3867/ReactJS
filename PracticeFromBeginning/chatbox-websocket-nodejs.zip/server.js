const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const port = 6969;
const server = http.createServer(express);
const wss = new WebSocket.Server({ server })

let clientss=0
wss.on('connection', function connection(ws) {
  clientss=clientss+1
  console.log("New Client Created : ",clientss)
  ws.on('message', function incoming(data) {
    console.log("message entered by Client : ",data)
    // console.log("all clients here are : ",wss.clients)
    wss.clients.forEach(function each(client) {
      // console.log("client forEach entered....")
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        // console.log("client entered if condition....")
        client.send(data);
      }
    })
  })
})

server.listen(port, function() {
  console.log(`Server is listening on ${port}!`)
})

