const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const HttpError = require("./routes/models/http-errors");

const placeRoutes = require("./routes/places-routes");
const userRoutes = require("./routes/users-routes");
const helmet = require('helmet')

const app = express(); //object that execute express() function

app.use(bodyParser.json());

// app.use(helmet.frameguard({

    // action:'allow-from',
    // domain:'http://www.google.com'
// }))


app.use((req,res,next) => {
  res.setHeader('Access-Control-Allow-Origin','*')
  res.setHeader('Access-Control-Allow-Headers',
           'Origin,X-Requested-With,Content-Type,Accept,Authorization')
  res.setHeader('Access-Control-Allow-Methods','GET,POST,PATCH,DELETE')
  res.setHeader('X-Frame-Options', 'allow-from https://www.google.com')
  next()
})

app.use("/api/places", placeRoutes);

app.use("/api/users", userRoutes);

app.get('/embed', function (req, res) {
  res.set('X-Frame-Options', "DENY")
  res.send('X-Frame-Options: ' + res.get('X-Frame-Options'))
})

app.use((req, res, next) => {
  throw new HttpError("[HttpError]route could not found", 404);
});
app.use((error, req, res, next) => {
  if (res.headerSent) {
    return next(error);
  }
  res.status(error.code || 500);
  res.json({ message: error.message || "An unknown error occured!!" });
});
    // mongoose.connect('mongodb://localhost:27017/products_test')

mongoose.connect('mongodb://localhost:27017/places')
    .then(()=>{
        app.listen(5000, () => {
            console.log("server[Express] listening to port:5000");
          });
    })
        .catch((error)=>{
            console.log('error occured while connecting to the DB')
        });
