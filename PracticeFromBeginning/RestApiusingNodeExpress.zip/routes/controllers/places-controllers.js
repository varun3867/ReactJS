const HttpError=require('../models/http-errors')
// const uuid=require('uuid')
const mongoose=require('mongoose')
const {validationResult}=require('express-validator')
const Place = require('../models/places')
const User=require('../models/User')
// let DUMMY_PLACES=[
//     {
//         id:'p1',
//         title:'Empire State Building',
//         description:'one of the best sky scrappers in the world',
//         location:{
//             lat:40.7844474,
//             lng:-73.9871516
//         },
//         address:'20 W 34th St, New York, NY 10001',
//         creator:'u1'
//     }
// ];
const getPlaceById =async (req,res,next)=>{
    console.log('GET Request in place')
    const placeId=req.params.pid;
    console.log('placeId is : ',placeId)
    let place;
    try{
        place=await Place.findById(placeId)
    }catch(err){
        const error = new HttpError('Something went wrong, could not find a place',300)
        return next(error)
    }

    
    if(!place){
        // const error=new Error('places not found')
        // error.code=(404)
        const error = new HttpError('[HttpError] places not found',404 )
        return next(error)
    }
    // res.json({place:place.toObject({getters:true})})
    res.json({place})

}

const getPlacesByUserId=async (req,res,next)=>{
    console.log('GET in placesByUserId')
    const userId=req.params.uid;
    console.log('userId is : ',userId)
    let userWithPlaces;
    try{
        userWithPlaces=await User.findById(userId).populate('places')

    }catch(err){
        const error = new HttpError('Fetching places failed, Please try again later')
        return next(error)
    }
    console.log('userWithPlaces is : ',userWithPlaces)
    // console.log('users are ',user)
    if(!userWithPlaces || userWithPlaces.places.length === 0 ){
        // const error=new Error('users not found')
        // error.code=404
    console.log('places not found')
        return next(new HttpError('[httpError] users not found',404))
    }
    // res.json({userWithPlaces})
    res.json({places:userWithPlaces.places.map(place=>place.toObject({getters:true}))})

}

const createPlace= async (req,res,next) =>{
    console.log('placesController createPlace')
    const errors=validationResult(req)
    console.log(errors)
    if(!errors.isEmpty()){
        console.log(errors)
        throw new HttpError('invalid input passed, please check your data',422)
    }
    const {title,description,coordinates,address,creator} =req.body
    const createdPlace=new Place({
        title,
        description,
        address,
        location:coordinates,
        image:'https://www.planetware.com/photos-large/MEX/mexico-top-places-cancun-mayan-riviera.jpg',
        creator
    })

    let user;
    try{
        user= await User.findById(creator)
    }catch(err){
        return next(new HttpError('[findingUser] Creating place failed, please try again',500))
    }

    console.log('creator is present : ',user)

    if(!user)
        return next(new HttpError('Could not find User for provided id',404))

    try{
        
        const sess=await mongoose.startSession()
        sess.startTransaction();
        console.log("Transaction started",createdPlace)
        await createdPlace.save()
        console.log("place saved")
        user.places.push(createdPlace)
        console.log('userId pushed')
        await user.save()
        console.log('transaction going to be commited')
        await sess.commitTransaction()
    }catch(err){
        const error = new HttpError('Creating place failed, please try again',500)
        return next(error)
    }
     res.status(201).json({place:createdPlace})
}

const updatePlace = async (req,res,next) => {
    console.log('entered into updatePlace') 
    const errors=validationResult(req)
    if(!errors.isEmpty()){
        console.log(errors)
        throw new HttpError('invalid input passed, please check the input',404)
    }
    const {title,description} = req.body
    const placeId=req.params.pid
    let place
    try{
        place = await Place.findById(placeId)
    }
    catch(err){
        const error = new HttpError('something went wrong could not update place',500)
        return next(error)
    }
    console.log('value is : ',placeId)
    
    place.title=title
    place.description=description

    try{
        await place.save()
   }
   catch(err){
       const error=new HttpError('Something went wrong could not update place',500)
       return next(error)
   }
    

    res.status(200).json({place:place.toObject({getters:true})} )

}
const deletePlace = async (req,res,next) => {
    console.log('entered into deletePlace')

    const placeId=req.params.pid
    let place
    try{
        place=await Place.findById(placeId).populate('creator')
    }
    catch(err){
        const error = new HttpError('Something went wrong, could not delete',500)
        return next(error)
    
    }
    if(!place)
        return next(new HttpError('Could not find the place for this id',404))

    console.log('[Delete Request ]',place)
    try{
        const sess=await mongoose.startSession()
        console.log('session started')
        sess.startTransaction()
        console.log('transaction started')
        await place.remove()
        console.log('removed')
        place.creator.places.pull(place)
        console.log('pulled')
        await place.creator.save()
        console.log('created')
        await sess.commitTransaction()
    }
    catch(err){
        const error=new HttpError('Something went wrong, could not delete')
        return next(error)
    }

    res.status(200).json({message:'Deleting Place'})

}
exports.getPlaceById=getPlaceById
exports.getPlacesByUserId=getPlacesByUserId
exports.createPlace=createPlace
exports.updatePlace=updatePlace
exports.deletePlace=deletePlace