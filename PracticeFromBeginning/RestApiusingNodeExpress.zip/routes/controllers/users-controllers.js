const uuid=require('uuid')
const HttpError=require('../models/http-errors')
const User = require('../models/User')
const {validationResult}=require('express-validator')
// const DUMMY_USERS=[
//     {
//     id:'u1',
//     name:'Max Schwarz',
//     email:'test@test.com',
//     password:'testers'
// }
// ]
const getUser = async (req,res,next) => {
    console.log('entered into getUser')
    let users
    try{
        users = await User.find({},'-password')
    }catch(err){
        return next(new HttpError('Fetching users failed, please try again',500))
    }
    res.json({users:users.map(user=>user.toObject({getters:true}))})
} 

const signin = async (req,res,next) => {
    console.log("user entered into signin")
    const errors=validationResult(req)
    if(!errors.isEmpty()){
        return next(new HttpError('Invali inputs passed, please check the data',422)) 
    }
    const {name,email,password} =req.body
    let userExist;
    try{
        userExist = await User.findOne({email:email})
    }
    catch(err){
        return next(new HttpError('[findOne]signUp failed, please try again later',500))
    }
    console.log('userExist is : ',userExist)
    if(userExist)
        return next(new HttpError('User exists already, please login instead',422))  


    const createdUser=new User({
        name,
        email,
        image:'https://img.etimg.com/thumb/width-640,height-480,imgsize-364552,resizemode-1,msid-71487423/two-indian-origin-persons-figure-in-fortunes-40-under-40-list.jpg',
        password,
        places : []
    })
    console.log('createdUser is : ',createdUser)

    try{
        console.log('entered to save the new user')
        await createdUser.save();
        console.log('crossed to check the new User')
    }catch(err){
        const error = new HttpError('signUp failed, please try again later',500)
        console.log('Error at saving data, while signup ',err)
        return next(error)
    }
    res.status(201).json({users:createdUser.toObject({getters:true})})

}

const login = async (req,res,next) => {
    const {email,password} = req.body;

    let userExist;
    try{
        userExist = await User.findOne({email:email})
    }
    catch(err){
        return next(new HttpError('Login failed, please try again later',500))
    }
    console.log('userExist is : ',userExist)

    
    if(!userExist || userExist.password !== password){
        console.log('entered into login failure')
        return next(new HttpError('could not identify user, seem credentials are wrong',404))
    }
    res.json({message:'Logged in!!'})

}


exports.getUser=getUser
exports. signin=signin
exports.login=login