import React, { Component } from 'react';
const express=require('express');
const app=express();
const routers=require('../Routes/routes')

app.use('/',routers)


export default class First extends Component {

    submitForm = () => {
        console.log('[First] entered into submitForm')
    }
    
    render() {
        return (
            <div>
                <h2>Form component</h2>
        <form action='/upload' onSubmit={this.submitForm} encType="multipart/form-data" method="POST">
        <input type="file" name="myFile"/>
        <input type="submit" value="Upload File"/>

    </form>
            </div>
        )
    }
}
