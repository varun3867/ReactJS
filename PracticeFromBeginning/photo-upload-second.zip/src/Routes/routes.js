// var express = require('express');
// var router = express.Router();

// /* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });

// module.exports = router;


const express=require('express')

const bodyParser=require('body-parser')

const multer=require('multer')

const mongodb=require('mongodb')

const fs=require('fs');

const path=require('path')

const app=express.Router()

app.use(bodyParser.urlencoded({extended:true}))

var storage = multer.diskStorage({

    filename:function(req,file,cb){
        cb(null,file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})

var upload=multer({
    storage:storage
})
const MongoClient=mongodb.MongoClient;
const url='mongodb://localhost:27017'

MongoClient.connect(url,{
    useUnifiedTopology:true,useNewUrlParser:true
},(err,client)=>{
    if(err) return console.log(err)
    db=client.db('Images');
    app.listen(3000,()=>
    console.log('mongodb Listening on port:3000'))
})

app.get('/',(req,res)=>{
    res.sendFile(__dirname + '/index.html')
})

app.post("/uploadPhoto",upload.single('myImage'),(req,res)=>{
    console.log('request in photo is : ',req)
    var img=fs.readFileSync(req.file.path)
    console.log('img is :',img)

    var encode_image=img.toString('base64') //encoding string into base64 string

    var finalImg={
        contentType:req.file.mimetype,
        path:req.file.path,
        image:new Buffer(encode_image,'base64')
    }


    db.collection('image').insertOne(finalImg,(err,result)=>{
        console.log(result)
        if(err) return console.log(err)
        console.log('save to database')

        res.contentType(finalImg.contentType);
        res.send(finalImg.image)
    })
})



app.listen(5000,() => {
    console.log('server Listening at port:5000')
})