import React from 'react';
import logo from './logo.svg';
import './App.css';
import First from './Component/First'

function App() {
  return (
    <div className="App">
     <First/>
    </div>
  );
}

export default App;
