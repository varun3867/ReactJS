const MongoClient=require('mongodb').MongoClient;
const url="mongodb+srv://varun:jESuBefPGcWf9AzW@clusters-1w6x8.mongodb.net/products_test?retryWrites=true&w=majority"
// const url =- "mongodb+srv://varun:jESuBefPGcWf9AzW@clusters-1w6x8.mongodb.net/products_test?retryWrites=true&w=majority";
const createProducts = async (req,res,next) => {

    const newProduct = {
        name:req.body.name,
        price:req.body.price
    }

    const client = new MongoClient(url)   //defining the client 

    try{
        await client.connect()   //establish the connection 
        const db=client.db()//refer to the database
        const result=db.collection('products').insertOne(newProduct) //refer to the database to 
        // the corresponding collection
    }
    catch(error){
        return res.json({message:'Could not store data'})
    }
    client.close()
    res.json({newProduct})

}

const getProducts = async (req,res,next) => {
    const client = new MongoClient(url)   //defining the client 
    let products;
    try{
        await client.connect()   //establish the connection 
        const db=client.db()//refer to the database
        products=await db.collection('products').find().toArray() //refer to the database to 
        // the corresponding collection
    }
    catch(error){
        return res.json({message:'Could not retrieve data'})
    }
    client.close()
    res.json({products})


}

exports.createProducts=createProducts
exports.getProducts=getProducts