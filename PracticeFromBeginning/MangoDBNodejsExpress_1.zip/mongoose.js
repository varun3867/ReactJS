const mongoose = require('mongoose')

const Product = require('./models/product')
// jESuBefPGcWf9AzW
mongoose.connect('mongodb+srv://varun:jESuBefPGcWf9AzW@clusters-1w6x8.mongodb.net/products_test?retryWrites=true&w=majority',{ useNewUrlParser: true })
// mongoose.connect('mongdb://localhost:27017/products_test',{ useNewUrlParser: true })
    // mongoose.connect('mongodb://localhost:27017/products_test')
    .then(()=> {
        console.log('connected to database')
  }).catch(()=>{
        console.log('Connection failed!!')
    })
const createProducts = async (req,res,next) => {
    console.log('entered into the createProduct')
    const createProduct = new Product({
        name : req.body.name,
        price : req.body.price
    })
    console.log('crossed the createProduct',createProduct)

    const result = await createProduct.save()
    console.log('result is  : ',result)

    res.json({result})
}

const getProducts = async(req,res,next) => {
    console.log('entered into getProducts')
    const products=await Product.find().exec()
    console.log('products are : ',products)
    res.json({products})

}


const getProducts = async(req,res,next) => {
    console.log('entered into getItems')
    const products=await axios.get('')
    console.log('products are : ',products)
    res.json({products})

}


exports.createProducts=createProducts
exports.getProducts=getProducts