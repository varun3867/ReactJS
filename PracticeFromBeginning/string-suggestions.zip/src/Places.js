// export default `amaravati
// anantapur
// chandragiri
// chittoor
// dowlaiswaram
// kadapa
// kurnool
// hyderabad
// machilipatnam
// nagarjunakoṇḍa
// rajahmundry
// srikakulam
// tirupati
// vijayawada
// visakhapatnam
// vizianagaram
// delhi
// andhrapradesh
// bidar
// bihar
// dwaraka
// adoni
// new Delhi
// ballari
// bangalore
// chikkamagaluru
// chitradurga
// davangere
// halebid
// hassan
// hubballi-Dharwad
// kalaburagi
// kolar
// madikeri
// mysuru
// raichur
// shivamogga
// shravanabelagola
// madanapalli
// nagaland
// nagasaki
// raipur
// rayachoti
// tiruvananthapuram
// tiruchanur
// trivendrum
// vittalam
// shrirangapattana`.split('\n');

export const tables={
    employee:{
        employeeName:' ', employeeNumber:' ', employeeAddress:' ', 
        employeeMobileNumber:' ', employeePersonalDetails:' '
    },
    student:{
        studentName:' ', studentNumber:' ', studentAddress:' ', 
        studentMobileNumber:' ', studentPersonalDetails:' '
    }, 
    manager:{
        managerName:' ', managerNumber:' ', managerAddress:' ', 
        managerMobileNumber:' ', managerPersonalDetails:' '
    }, 
    seniorManager:{
        seniorManagerName:' ', seniorManagerNumber:' ', seniorManagerAddress:' ', 
        seniorManagerMobileNumber:' ', seniorManagerPersonalDetails:' '
    },
    winterManager:{
        winterManagerName:' ', winterManagerNumber:' ', winterManagerAddress:' ', 
        winterManagerMobileNumber:' ', winterManagerPersonalDetails:' '
    }
}


// export const 
