// const axios = require('axios');
// var MongoClient = require('mongodb').MongoClient;
// var url = "mongodb://localhost:27017/";
// let fetchValue=[]



// let socket = io => {
//     io.on('connection', client => {
//       let arr =[]
//       setInterval(() => {
        
//         MongoClient.connect(url,{useUnifiedTopology: true}, function(err, db) {
//           if (err) throw err;
//           var dbo = db.db("myDatabasePractice");
//           //Find all documents in the customers collection:
//           dbo.collection("dupCollection").find({}).toArray(function(err, result) {
//             if (err) throw err;
//             // console.log('result',result);
//             var fetchedValueArray = result.map(it=>Object.keys(it).filter(i=>i=='itemValue')
//                                          .map(i=>it[i]))
            
//             var fetchValue = fetchedValueArray.join()
//             console.log('fetched value is : ',fetchValue)
//             console.log('array values are : ',arr,arr.length)
//             if(arr.length==0){
//               console.log("length is empty " )
//               arr[0] = fetchValue
//               var gvalue = Math.floor(Math.random() * 10000)
//               client.emit('gvalue', gvalue);
//               console.log(gvalue)
//             }
//             else{
//               if(arr[0]==fetchValue){
//                 console.log('Database not Changed',arr[0])
//               }
//               else{
//                 console.log('Database changed : ',arr[0])
//                 arr[0]=fetchValue
//                 var gvalue = Math.floor(Math.random() * 10000)
//                 client.emit('gvalue', gvalue);
//                 console.log(gvalue)
//               }
//             }
            
            
            
//           // setInterval(() => {
//           // var gvalue = Math.floor(Math.random() * 10000)
//           //   client.emit('gvalue', gvalue);
//           //   console.log(gvalue)
//           //   console.log('inside',fetchValue)
//           // }, 5000);
//             db.close();
//           });
//         });

//       }, 5000);
    






//       });
//   }
//   module.exports = socket;






  
  
//       // let arr = [] 
//       // setInterval(() => {   
//       //   axios.get(`https://localhost:3000/regular`)
//       //      .then(res => {
//       //      const data = res.data;
//       //      let temp = data.value
//       //       if(arr==null){
//       //         arr[0]=temp
//       //       }
//       //       else{
//       //         if(arr[0]==temp){
//       //           return;
//       //         }
//       //         else{
//       //           arr[0]=temp
//       //           var gvalue = Math.floor(Math.random() * 10000)
//       //           client.emit('gvalue', gvalue);
//       //         }
//       //       }
//       //      })
//       //    }, 5000);