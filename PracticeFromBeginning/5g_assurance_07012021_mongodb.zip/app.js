
var express = require('express');
app = express(),
port = process.env.PORT || 8888;
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
let dayDiffSkip=0;
let halfDaySkip=0;
let sixHourSkip=0;
let oneHourSkip=0;
let halfAnHourSkip=0;
let fifteenMinutesSkip=0;
let oneMinuteSkip=0;
let halfSecondSkip=0;
let fifteenSecondSkip=0;
let threeSecondSkip=0;
let oneSecondSkip=0;



app.use(function (request, response, next) {
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});
// MongoClient.connect(url,{useUnifiedTopology: true}, function(err, db) {
//   if (err) throw err;
//   var dbo = db.db("myDatabasePractice");
//   dbo.collection("dupCollection").find({}).toArray(function(err, result) {
//   console.log('values are : ',result)
//   })

//   db.close();
// });
 


// const cors = require('cors');
app.get('/reg',(req,res)=>{
  let clickTimes = req.query.click;
  let selected = req.query.select;
  let toDate=req.query.toDate;
  let fromDate = req.query.fromDate;
  console.log("selected move is : "+selected)
  console.log("fromDate from React : ",fromDate)
  console.log("toDate from React : ",toDate)
  if(toDate.substring(toDate.length-2,toDate.length)=="PM"){
    let toHoursDup = toDate.substring(11,13)
    console.log('toHours issssssssssss : ',toHoursDup)
    // if(parseInt(toHoursDup)<10)
    let newHour = parseInt(toHoursDup)+12
    console.log('newwwwwwwwwww  : ',newHour)
    let dupToDate=toDate.substring(0,11)+newHour+toDate.substring(13,toDate.length)
    console.log("dupppppppppppppppppppptttttt : ",dupToDate)
    toDate=dupToDate
  }
  var newToDate = toDate.substring(0, toDate.length - 3);
  console.log("toDate : ",newToDate+":00.040Z")
  var newFromDate = fromDate.substring(0, fromDate.length - 3);
  console.log("fromDate : ",newFromDate+":00.040Z")
  let fromDay=fromDate.substring(8,10);
  let toDay = toDate.substring(8,10)
  let dayDiff = toDay - fromDay;
  console.log("fromDay toDay dayDiff : ",fromDay,toDay,dayDiff)
  let toHours = toDate.substring(11,13)
  let toMinutes = toDate.substring(14,16)
  let fromHours = fromDate.substring(11,13)
  let fromMinutes = fromDate.substring(14,16)
  // console.log("fromHour fromMinute : ",fromHours,fromMinutes)
  // console.log("toHour toMinute : ",toHours,toMinutes)
  let hoursDiff = toHours - fromHours
  let minutesDiff = toMinutes - fromMinutes
  console.log("hoursDiff minutesDiff : ",hoursDiff,minutesDiff)
  console.log('clicked times are : ',clickTimes)
  if(isNaN(hoursDiff) || isNaN(minutesDiff)|| isNaN(dayDiff) ||
        hoursDiff<0 || minutesDiff<0 || dayDiff<0){
    console.log("selected data is invalid ???????...")
  }
  else{
    console.log('selected data is valid...............')
  MongoClient.connect(url,{useUnifiedTopology: true}, function(err, db) {
    if (err) throw err;
    var dbo = db.db("Sample5G");
    console.log("clicked inside mongo is : ",clickTimes)
    if(selected=="next"){
      if(dayDiff==0 && hoursDiff==0 && (minutesDiff==1)){
        oneSecondSkip=oneSecondSkip+9
      }
   else if(dayDiff==0 && hoursDiff==0 && (minutesDiff<=3 && minutesDiff>1)){
        threeSecondSkip =threeSecondSkip+27
      }

      else if(dayDiff==0 && hoursDiff==0 && (minutesDiff<12 && minutesDiff>3)){
        fifteenSecondSkip = fifteenSecondSkip+135;
      }
      if(dayDiff==0 && hoursDiff==0 && (minutesDiff<25 && minutesDiff>12)){
        halfSecondSkip=halfSecondSkip+270
      }
      else if(dayDiff==0 && hoursDiff==0 && (minutesDiff<=60 && minutesDiff>=25)){
        oneMinuteSkip=oneMinuteSkip+600
      }
      else if(dayDiff==0 && (hoursDiff<10 && hoursDiff>0)){
        fifteenMinutesSkip=fifteenMinutesSkip+9000
      }
      else if(dayDiff>=20){
        console.log('next : entered into day>20')
        dayDiffSkip=dayDiffSkip+864000
      }
      else if(dayDiff>=10 && dayDiff<20){
        console.log('next : entered into days between 10 and 20')
        halfDaySkip=halfDaySkip+432000;
        dayDiffSkip=0;
        sixHourSkip=0;
      }
      else if(dayDiff<10 && dayDiff>2){
        console.log('next : entered into days between 10 and 2')

        sixHourSkip=sixHourSkip+216000;
        halfDaySkip=0;
        dayDiffSkip=0;
      }
      else if((dayDiff<=2 && dayDiff>0) || (dayDiff<=2 && (hoursDiff<=24 && hoursDiff>=20))){
        console.log('next : entered into days less than 2 and hours between 24 and 20')
        oneHourSkip=oneHourSkip+36000;
      }
      else if(dayDiff==0 && (hoursDiff<20 && hoursDiff>=10)){
        console.log('next : entered into days  is 0 and hours between 10 and 20')
          halfAnHourSkip=halfAnHourSkip+18000
      }
      
    }
    else if(selected=="back"){
         if(dayDiff==0 && hoursDiff==0 && (minutesDiff==1)){
           oneSecondSkip=oneSecondSkip-9
         }
      else if(dayDiff==0 && hoursDiff==0 && (minutesDiff<=3 && minutesDiff>1)){
        threeSecondSkip =threeSecondSkip-27
      }
      else if(dayDiff==0 && hoursDiff==0 && (minutesDiff<12 && minutesDiff>3)){
        fifteenSecondSkip = fifteenSecondSkip-135;
      }
      else if(dayDiff==0 && hoursDiff==0 && (minutesDiff<25 && minutesDiff>12)){
        halfSecondSkip=halfSecondSkip-270
      }
      else  if(dayDiff==0 && hoursDiff==0 && (minutesDiff<=60 && minutesDiff>=25)){
        oneMinuteSkip=oneMinuteSkip-600
      }
      else if(dayDiff==0 && (hoursDiff<10 && hoursDiff>0)){
        fifteenMinutesSkip=fifteenMinutesSkip-9000
      }
      else if(dayDiff>20){
        dayDiffSkip=dayDiffSkip-864000
      }
      else if(dayDiff>5 && dayDiff<20){
        halfDaySkip=halfDaySkip-432000;
        dayDiffSkip=0;
        sixHourSkip=0;
      }
      else if(dayDiff<10 && dayDiff>2){
        sixHourSkip=sixHourSkip-216000;
        dayDiffSkip=0;
        halfDaySkip=0;
      }
      else if((dayDiff<=2 && dayDiff>0) || (dayDiff<=2 && (hoursDiff<=24 && hoursDiff>=20))){
        oneHourSkip=oneHourSkip-36000;
      }
      else if(dayDiff==0 && (hoursDiff<20 && hoursDiff>=10)){
          halfAnHourSkip=halfAnHourSkip-18000
      }
      
    }  
   console.log("before entering into here.......conditions [Main]")
   if(dayDiff==0 && hoursDiff==0 && (minutesDiff==1)){

    console.log("[Main]entered minutes 1...")
    dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(oneSecondSkip).limit(9).toArray(function(err, result) {
      if (err) throw err;
      let sum =0;        
      let finalResult = []
      // console.log(result)
      result.map((it,index)=>{
        sum=sum+it.value
        if(index%1==0){
           console.log("index values is :\n ",index)
           console.log(it)
          //  console.log("value of 1 index is : \n",it)
           let value=sum;
           if(index!=0){
            value = sum/1
           }
          //  console.log("average of 1 values is : \n",value)
           sum=0;
           let timestamp=it.timestamp;
           ob={timestamp,value}
           // return ob;
           finalResult.push(ob)
         // return it;
         // console.log(index)
        }
      })
      let basic = "seconds"
      let obsend = {finalResult,basic}
      res.send(obsend)
      db.close();
      console.log("mongodb closed....")
      console.log('finalllllll is : ',obsend)
    });




   }


   else if(dayDiff==0 && hoursDiff==0 && (minutesDiff<=3 && minutesDiff>1)){
     
    console.log("[Main]entered minutes is between 3 and 1...")
    dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(threeSecondSkip).limit(27).toArray(function(err, result) {
      if (err) throw err;
      let sum =0;        
      let finalResult = []
      // console.log(result)
      result.map((it,index)=>{
        sum=sum+it.value
        if(index%3==0){
           console.log("index values is :\n ",index)
           console.log(it)
          //  console.log("value of 3 index is : \n",it)
           let value=sum;
           if(index!=0){
            value = sum/3
           }
          //  console.log("average of 3 values is : \n",value)
           sum=0;
           let timestamp=it.timestamp;
           ob={timestamp,value}
           // return ob;
           finalResult.push(ob)
         // return it;
         // console.log(index)
        }
      })
      let basic = "seconds"
      let obsend = {finalResult,basic}
      res.send(obsend)
      db.close();
      console.log("mongodb closed....")
      console.log('finalllllll is : ',obsend)
    });



   }
   else if(dayDiff==0 && hoursDiff==0 && (minutesDiff<12 && minutesDiff>3)){
    console.log("[Main]entered minutes is between 12 and 25...")
    dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(fifteenSecondSkip).limit(135).toArray(function(err, result) {
      if (err) throw err;
      let sum =0;        
      let finalResult = []
      // console.log(result)
      result.map((it,index)=>{
        sum=sum+it.value
        if(index%15==0){
           console.log("index values is :\n ",index)
           console.log(it)
          //  console.log("value of 15 index is : \n",it)
           let value=sum;
           if(index!=0){
            value = sum/15
           }
          //  console.log("average of 15 values is : \n",value)
           sum=0;
           let timestamp=it.timestamp;
           ob={timestamp,value}
           // return ob;
           finalResult.push(ob)
         // return it;
         // console.log(index)
        }
      })
      let basic = "seconds"
      let obsend = {finalResult,basic}
      res.send(obsend)
      db.close();
      console.log("mongodb closed....")
      console.log('finalllllll is : ',obsend)
    });




   }




   else if(dayDiff==0 && hoursDiff==0 && (minutesDiff<25 && minutesDiff>=12)){

    console.log("[Main]entered minutes is between 12 and 25...")
    dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(halfSecondSkip).limit(270).toArray(function(err, result) {
      if (err) throw err;
      let sum =0;        
      let finalResult = []
      // console.log(result)
      result.map((it,index)=>{
        sum=sum+it.value
        if(index%30==0){
           console.log("index values is :\n ",index)
           console.log(it)
          //  console.log("value of 30 index is : \n",it)
           let value=sum;
           if(index!=0){
            value = sum/30
           }
          //  console.log("average of 30 values is : \n",value)
           sum=0;
           let timestamp=it.timestamp;
           ob={timestamp,value}
           // return ob;
           finalResult.push(ob)
         // return it;
         // console.log(index)
        }
      })
      let basic = "seconds"
      let obsend = {finalResult,basic}
      res.send(obsend)
      db.close();
      console.log("mongodb closed....")
      console.log('finalllllll is : ',obsend)
    });



   }
   else if(dayDiff==0 && hoursDiff==0 && (minutesDiff<=60 && minutesDiff>=25)){
    console.log("[Main]entered minutes is between 60 and 30...")
    dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(oneMinuteSkip).limit(600).toArray(function(err, result) {
      if (err) throw err;
      let sum =0;        
      let finalResult = []
      // console.log(result)
      result.map((it,index)=>{
        sum=sum+it.value
        if(index%60==0){
           console.log("index values is :\n ",index)
           console.log(it)
          //  console.log("value of 60 index is : \n",it)
           let value=sum;
           if(index!=0){
            value = sum/60
           }
          //  console.log("average of 60 values is : \n",value)
           sum=0;
           let timestamp=it.timestamp;
           ob={timestamp,value}
           // return ob;
           finalResult.push(ob)
         // return it;
         // console.log(index)
        }
      })
      let basic = "minutes"
      let obsend = {finalResult,basic}
      res.send(obsend)
      db.close();
      console.log("mongodb closed....")
      console.log('finalllllll is : ',obsend)
    });


   }

   else if(dayDiff==0 && (hoursDiff<10 && hoursDiff>0)){
    console.log("[Main]entered hours is between 10 and 1...")
    dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(fifteenMinutesSkip).limit(9000).toArray(function(err, result) {
      if (err) throw err;
      let sum =0;        
      let finalResult = []
      // console.log(result)
      result.map((it,index)=>{
        sum=sum+it.value
        if(index%900==0){
           console.log("index values is :\n ",index)
           console.log(it)
          //  console.log("value of 900 index is : \n",it)
           let value=sum;
           if(index!=0){
            value = sum/900
           }
          //  console.log("average of 900 values is : \n",value)
           sum=0;
           let timestamp=it.timestamp;
           ob={timestamp,value}
           // return ob;
           finalResult.push(ob)
         // return it;
         // console.log(index)
        }
      })
      let basic = "minutes"
      let obsend = {finalResult,basic}
      res.send(obsend)
      db.close();
      console.log("mongodb closed....")
      console.log('finalllllll is : ',obsend)
    });



  }

    else if(dayDiff==0 && (hoursDiff<20 && hoursDiff>=10)){
      console.log("[Main]entered hours is between 10 and 20...")
      dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(halfAnHourSkip).limit(18000).toArray(function(err, result) {
        if (err) throw err;
        let sum =0;        
        let finalResult = []
        // console.log(result)
        result.map((it,index)=>{
          sum=sum+it.value
          if(index%1800==0){
             console.log("index values is :\n ",index)
             console.log(it)
            //  console.log("value of 1800 index is : \n",it)
             let value=sum;
             if(index!=0){
              value = sum/1800
             }
            //  console.log("average of 1800 values is : \n",value)
             sum=0;
             let timestamp=it.timestamp;
             ob={timestamp,value}
             // return ob;
             finalResult.push(ob)
           // return it;
           // console.log(index)
          }
        })
        let basic = "minutes"
        let obsend = {finalResult,basic}
        res.send(obsend)
        db.close();
        console.log("mongodb closed....")
        console.log('finalllllll is : ',obsend)
      });



    }
    else if((dayDiff<=2 && dayDiff>0)|| (dayDiff<=2 && (hoursDiff<=24 && hoursDiff>=20))){
      console.log("[Main]entered days less than 2 hours is between 24 and 20...")
      dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(oneHourSkip).limit(36000).toArray(function(err, result) {
        if (err) throw err;
        let sum =0;        
        let finalResult = []
        // console.log(result)
        result.map((it,index)=>{
          sum=sum+it.value
          if(index%3600==0){
             console.log("index values is :\n ",index)
             console.log(it)
            //  console.log("value of 3600 index is : \n",it)
             let value=sum;
             if(index!=0){
              value = sum/3600
             }
            //  console.log("average of 3600 values is : \n",value)
             sum=0;
             let timestamp=it.timestamp;
             ob={timestamp,value}
             // return ob;
             finalResult.push(ob)
           // return it;
           // console.log(index)
          }
        })
        let basic = "halfDay"
        let obsend = {finalResult,basic}
        res.send(obsend)
        db.close();
        // console.log("MongoDb Closed...........")
      });
    }

    else if(dayDiff>=20){
      console.log("[Main]entered days is greater than 20...")

    dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(dayDiffSkip).limit(864000).toArray(function(err, result) {
      if (err) throw err;
      let sum =0;        
      let finalResult = []

      // console.log(result)
      result.map((it,index)=>{
        sum=sum+it.value
        if(index%86400==0){
           // console.log("index values is :\n ",index)
           console.log("value of 86400 index is : \n",it)
           let value=sum;
           if(index!=0){
            value = sum/86400
           }
           console.log("average of 86400 values is : \n",value)
           sum=0;
           let timestamp=it.timestamp;
           ob={timestamp,value}
           // return ob;
           finalResult.push(ob)
         // return it;
         // console.log(index)
        }
      })
      let basic = "day"
      let obsend = {finalResult,basic}
      res.send(obsend)
      db.close();
    });
  }

  else if(dayDiff>=10 && dayDiff<20){
    console.log("[Main]entered days is between 10 and 20...")
    dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(halfDaySkip).limit(432000).toArray(function(err, result) {
      if (err) throw err;
      // console.log("result at a time is : ",result)
      let sum =0;        
      let finalResult = []

      // console.log(result)
      result.map((it,index)=>{
        sum=sum+it.value
        if(index%43200==0){
           // console.log("index values is :\n ",index)
           console.log("value of 43200 index is : \n",it)
           let value=sum;
           if(index!=0){
            value = sum/43200
           }
           console.log("average of 43200 values is : \n",value)
           sum=0;
           let timestamp=it.timestamp;
           ob={timestamp,value}
           // return ob;
           finalResult.push(ob)
         // return it;
         // console.log(index)
        }
      })
      let basic = "halfDay"
      let obsend = {finalResult,basic}
      res.send(obsend)
      db.close();
    });

  }
  else if(dayDiff<10 && dayDiff>2){
    console.log("[Main]entered days is between 10 and 2...")
    dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date(newToDate+":00.040Z")}},{timestamp:{$gte:new Date(newFromDate+":00.040Z")}}]}).skip(sixHourSkip).limit(216000).toArray(function(err, result) {
      if (err) throw err;
      // console.log("result at a time is : ",result)
      let sum =0;        
      let finalResult = []

      // console.log(result)
      result.map((it,index)=>{
        sum=sum+it.value
        if(index%21600==0){
           // console.log("index values is :\n ",index)
           console.log("value of 21600 index is : \n",it)
           let value=sum;
           if(index!=0){
            value = sum/21600
           }
           console.log("average of 21600 values is : \n",value)
           sum=0;
           let timestamp=it.timestamp;
           ob={timestamp,value}
           // return ob;
           finalResult.push(ob)
         // return it;
         // console.log(index)
        }
      })
      let basic = "halfDay"
      let obsend = {finalResult,basic}
      res.send(obsend)
      db.close();
    });

  }
  });
}
})
app.get('/regular', (req, res) => {
  // res.send('Welcome to Socket.IO App! - Clue Mediator');
  MongoClient.connect(url,{useUnifiedTopology: true}, function(err, db) {
    if (err) throw err;
    var dbo = db.db("Sample5G");
    //Find all documents in the customers collection:
    dbo.collection("Timer").find({$and:[{timestamp:{$lte:new Date("2020-12-02T11:00:04.040Z")}},{timestamp:{$gte:new Date("2020-12-02T11:00:00.040Z")}}]}).toArray(function(err, result) {
      if (err) throw err;
      console.log('result',result);
      var diff = new Date('')
      res.send(result)
      db.close();
    });
  });
  
});

var server = app.listen(port, () => {
        console.log('Server started on: ' + port);
});

// attach socket to the node server
// var io = require('socket.io')(server);
// const io = require('socket.io')(server, {
//     cors: {
//       origin: '*',
//     }
//   });
// require('./socket')(io);























// var app = require('express')();
// var http = require('http').Server(app);
// var io = require('socket.io')(http);


// app.use((req,res,next)=>{
//     res.setHeader("Access-Control-Allow-Origin", "http://localhost:4200");
//     res.header(
//         "Access-Control-Allow-Headers",
//         "Origin, X-Requested-With, Content-Type, Accept"
//     );
//   next();
// })

// app.get('/',(req,res)=>{
//     res.sendFile(__dirname+'/index.html');
// })

// io.on('connection',(socket)=>{
//         console.log("new connection established...")
// })

// setInterval(() => {
//     var stockprice = Math.floor(Math.random() * 1000)
//     io.emit('stock price',stockprice)
// }, 5000);


// http.listen(8888,()=>{
//     console.log('server listening on port 8888')
// })