import React from 'react';
import Content from './Content'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Card,CardGroup} from "react-bootstrap";

class CardScreen extends React.Component {

   render() {
     console.log('[App] rendering component')
      return (
         <div>
         <Card style={{ borderRadius:"15px" }}>
         <Card.Body>
          
               Some quick example test is writtern belowlkajdflkdajfljf
               <br></br>
               Some quick example 
               <br></br>
               Some quick example
               <br></br>
               Some quick example
               <br></br>
               Some quick example
               <br></br>
               
        
           
         </Card.Body>
         </Card>   
         {/* <h2>{this.state.data}</h2> */}
         </div>
      );
   }
}

export default CardScreen;