import React from 'react';
import Content from './Content'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Card,CardGroup} from "react-bootstrap";
import CardScreen from './CardScreen';
import "./App.css";
class App extends React.Component {

   render() {
     console.log('[App] rendering component')
      return (
            <div className="screen">
               <div className="row" style={{padding:"20px"}} >
                  <div className="lg-col-5 md-col-3 sm-col-1" style={{padding:"20px"}}>
                     <CardScreen/>
                  </div>
                  <div className="lg-col-5 md-col-3 sm-col-1"  style={{padding:"20px"}}>
                     <CardScreen/>
                  </div>
               </div>
               <div className="row" style={{padding:"20px"}}>
                  <div className="lg-col-5 md-col-3 sm-col-1"  style={{padding:"20px"}}>
                     <CardScreen/>
                  </div>
                  <div className="lg-col-5 md-col-3 sm-col-1"  style={{padding:"20px"}}>
                     <CardScreen/>
                  </div>
               </div>
         </div>
      );
   }
}

export default App;