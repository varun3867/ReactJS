import React, {Component} from "react";
import classes from '../components/Simpletextarea.css';
import InputTrigger from 'react-input-trigger';


class Simpletextarea extends Component {
    constructor(props) {
        super(props);
        this.state = { 
         suggestions: [],
         text:'',
         count:0,
         arrValueLength:0,
         renderCount:0,
         lastLetter:'',
         valDup:'',
         top: null,
         left: null,
         showSuggestor: false,
         startPosition: null,
         clickedEnter:0,
         lastLetterValue:false
        };
        this.onTextChange = this.onTextChange.bind(this);
      }

      shouldComponentUpdate(newProps, newState) {
        console.log('[App] Component SHOULD UPDATE!');
        // console.log('nextProps',newProps)
        // this.setState(() => ({renderCount:this.state.renderCount+1}));
        console.log('nextState',newState,this.state.renderCount)
          return true;
       }
      componentDidUpdate(){
        console.log('entered into componentDidUpdate[STA]',this.state.renderCount)
        console.log('state count : ',this.state.count)
        console.log('suggestions in state are : ',this.state.suggestions)
        console.log('suggestions hook placed : ',this.state.left,this.state.top,
                this.state.showSuggestor,this.state.startPosition)

      }

      // keyDown = (event) => {
      //   // console.log('entered into keyDown...')
      //   // console.log('keyDown is : ',event.keyCode)
      // }
      onTextChange(e) {
        console.log('entered into onTextChange()',e.target.value,this.state.clickedEnter)
        // if(this.state.clickedEnter === 0){
          // console.log('Not clicked on ENTER')
        
   
          const items = [...this.props.items];
        console.log(items);
        let value= e.target.value;
        // value=value.replace('\n',' ')
        let valDup=value
        // valDup = valDup.replace(/\n/g, "");
        console.log('String Replace is : ',valDup)
        let lengthElement=valDup.length
        this.setState({valDup:valDup})
        let lastLetter = valDup.slice(lengthElement-1,lengthElement)
        // let endLetter = valDup.slice(lengthElement-1,lengthElement+1)
        console.log('last letter is : ',valDup,lastLetter)
        if(lastLetter === '\n'){
          console.log('CLICKED ON ENTER ')
          this.setState({lastLetterValue:false},()=>{
            
          })
        }
        if(lastLetter === ' '){
          this.setState({lastLetterValue:true},()=>{

          })
        }
        console.log('value in onTextChange() : ',valDup)
        // let arr = valDup.split('\n');
        // arr = valDup.split('\n')
        let arr =[]
        //lastLetter!=='\n' && 
        if(lastLetter!=='\n' && this.state.lastLetterValue){
          console.log('value of lastletter is SPACE',this.state.lastLetter)
          // arr=arr.replace('\n', "red");
          arr=valDup.split(' ')
        }
        // if(!this.state.lastLetterValue){
        else{
          console.log('value of lastletter is ENTER',this.state.lastLetter)
          
          // arr=arr.replace('\n', "red");
          arr=valDup.split('\n')
          // this.setState(() => ({top:this.state.top+2}));
        }
        console.log('arr value inside this is after all is : ',arr)

        let counts = this.state.count
        console.log('arr value is : ',counts,arr[this.state.count])
   
        let suggestions = [];
        console.log('suggestion : ',suggestions,valDup) 
        this.setState(() => ({renderCount:this.state.renderCount+1}));
        if(arr[this.state.count] && lastLetter !== ' ') {  
          console.log('entered into if loop :value in array taking : ',this.state.count,arr) 
            console.log('items are : ',this.props.items)
          // const regex = new RegExp(`^${arr[this.state.count]}`,'i');
          const regex = new RegExp(`^${arr[this.state.count]}`,'i');

          console.log('regex value is : ',regex) 

          suggestions= this.props.items.filter(v=> regex.test(v));

     

          console.log('suggestions value is : ',suggestions) 
          if(suggestions.length>3){
            suggestions.length-=1
         

          }
          console.log('value we enered space or not : ',valDup)
          let valueLength = valDup.length
          let arrValueLength=arr[this.state.count].length
          console.log('array value length is : ',arrValueLength)
          this.setState(() => ({arrValueLength :arrValueLength}));
          console.log('length of value entered : ',valueLength)
         let letterNeed = value.slice(valueLength-1,valueLength)
         console.log('letter we need is : ',letterNeed)
      
        }
        this.setState(() => ({lastLetter :lastLetter}));
        // if(lastLetter === ' ' || lastLetter === '\n')
        if(lastLetter === ' ')
        {
          this.setState(() => ({count:this.state.count+1}));
        }
        this.setState(() => ({suggestions ,text :valDup}));
      }
      keyPressed= (event) => {
        console.log('keyPressed : ',event,event.keyCode,this.state.lastLetter)
        console.log('state value in keyPressed is : ',this.state.value)
        console.log('location in keyPressed is : ',event.location)
        // if(event.keyCode === 13){
        //   console.log('clicked on ENTER : ',event.keyCode)
        //   this.setState(() => {clickedEnter:1})
        // }
        // else{
        //   this.setState(() => {clickedEnter:0})

        // }
        const valueDup=this.state.valDup
        const lengthDup=valueDup.length
        const selectSpace=valueDup.slice(lengthDup-2,lengthDup-1)
        console.log('value is in : ',valueDup)
        console.log('selectSpace is in : ',selectSpace)
        // this.state.lastLetter === ' ' || 
        if((event.keyCode === 8 && selectSpace === ' ')){
          console.log('entered into if of keyPressed')
          // if(this.state.count >0 ){
            this.setState(() => ({count:this.state.count-1}));
            
          // }
        }

      }

      suggestionSelected (value) {
        console.log('entered into suggestionSelected')
        console.log('count value is in : suggestionSelected',this.state.arrValueLength)
        const stringValue = this.state.arrValueLength
        console.log('StringValue is : ',stringValue)
        this.setState(() => ({
          text:this.state.text+value.substring(stringValue),
          suggestions: [],

        }))
      }
      renderSuggestions= () => {
        console.log('entered into renderSuggestions')
        const { suggestions } =this.state;
        console.log("Suggestions : "+suggestions);
        
        if(suggestions.length === 0 ) {
          return null;
        }
       return (
      <ul className={classes.textareaul}>
        {suggestions.map((item) => <li  className={classes.textareali} 
        // onKeyDown={this.keyDown()}
        onClick= {() =>this.suggestionSelected(item)}>{item}</li>)}
      </ul>
       )
      
      }

      toggleSuggestor(metaInformation) {
        const { hookType, cursor } = metaInformation;
        console.log("the metadeta information is:",metaInformation);
        console.log("the cursor value is:",cursor);
        // console.log('Before entering : ',hookType)
        // console.log("the cursor value is:",Number.cursor.height);
        console.log("the cursor value is:",cursor.height);



        if (hookType === 'start' || hookType === 'typing') {
          // console.log('entered inside : ',hookType)
          this.setState({
            showSuggestor: true,
            left: cursor.left,
            top: 2, // we need to add the cursor height so that the dropdown doesn't overlap with the `@`.
            startPosition: cursor.selectionStart,
          });
        
        }
      }
    
    
      render() {
        console.log('entered into render() [STA]')
        const {text} = this.state;
        return (
          // <div className={classes.firstDiv}>
          <div>
             <InputTrigger
          trigger={{
            keyCode: 32
          }}
         
          onStart={(metaData) => { this.toggleSuggestor(metaData); }}
          onType={(metaData) => { this.toggleSuggestor(metaData); }}>
             <textarea onChange={this.onTextChange} onKeyDown={this.keyPressed} ></textarea>
           </InputTrigger>
           <div
          style={{
            position: "absolute",
            width: "350px",
            height:"500px",
            background: "white",   
            top: this.state.top,
            left: this.state.left,
          }}>
             {/* <textarea className={classes.textarea}  value={text} onChange={this.onTextChange} onKeyDown={this.keyPressed} /> */}
             <div id='SuggestionBox'>{this.renderSuggestions()}</div>
             {/* {this.changeHandler} */}</div>
         </div>
        );
      }
}

export default Simpletextarea;