const http2 = require ("http2")
// const fs = require("fs")
const port = 3000
const spdy = require('spdy')
const express = require('express')
const path = require('path')
const fs = require('fs')
const { nextTick } = require("process")

const app = express()
// const server = http2.createSecureServer({
//     key: fs.readFileSync('./key.pem', 'utf8'),
//     cert: fs.readFileSync('./cert.pem', 'utf8')
// })

app.use((req,res,next)=>{
    res.setHeader("Access-Control-Allow-Origin", "http://localhost:4200");
    res.header(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept"
    );
  next();
})
app.get('/came', (req, res) => {
    res.status(200)
    var gvalue = Math.floor(Math.random() * 100)
    // console.log()
    res.send({value: gvalue})
})
const options = {
    key: fs.readFileSync('./key.pem', 'utf8'),
    cert: fs.readFileSync('./cert.pem', 'utf8')
}

spdy
  .createServer(options, app)
  .listen(port, (error) => {
    if (error) {
      console.error(error)
      return process.exit(1)
    } else {
      console.log('Listening on port: ' + port + '.')
    }
  })