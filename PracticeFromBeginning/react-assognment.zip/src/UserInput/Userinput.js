import React, { Component } from 'react'

export default class Userinput extends Component {
   
    style={
        border:'1px solid red',
        color:'brown',
        marginBottom:'20px'
    };
    render(props) {
        return (
            <div>
                <input type='text' style={this.style} onChange={this.props.change} value={this.props.username}/>
            </div>
        )
    }
}
