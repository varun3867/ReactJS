import React, { Component } from 'react'
import './App.css';
import Input from './UserInput/Userinput';
import Output from './UserOutput/useroutput';

export default class App extends Component {
  state={
    username:"RAnhit!!"
  }

  manpulateStateHandler = (event) => {
    this.setState({
      username:event.target.value
    })
  }
  render() {
    return (
      <div className="App">
             <Input change={this.manpulateStateHandler} username={this.state.username}/>
             <Output username={this.state.username}/>
             <Output username='Ranhit'/>
           </div>
    )
  }
}
//  App() {
  
//   return (
//     <div className="App">
//       <Input/>
//       <Output username={this.state.username}/>
//       <Output username='Ranhit'/>
//     </div>
//   );
// }

// export default App;
