import React, { Component } from 'react'
import './useroutput.css';

export default class useroutput extends Component {
    render(props) {
        return (
            <div className='userOutput'>
                <p>this is {this.props.username}</p>
                <p>yes....</p>
            </div>
        )
    }
}
