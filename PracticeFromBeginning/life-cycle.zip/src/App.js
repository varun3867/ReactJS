import React from 'react';
import Content from './Content'

class App extends React.Component {
   constructor(props) {
      super(props);
      
      this.state = {
         data: 0
      }
      this.setNewNumber = this.setNewNumber.bind(this)
   };
   setNewNumber() {
     console.log('[App] setting new number')
      this.setState({data: this.state.data + 1})
   }
   componentWillMount() {
    console.log('[App] Component WILL MOUNT!')
 }
 componentDidMount() {
    console.log('[App] Component DID MOUNT!')
 }

 shouldComponentUpdate(newProps, newState) {
  console.log('[App] Component SHOULD UPDATE!');
  console.log('nextProps',newProps)
  console.log('nextState',newState,this.state.data)
    return true;
 }
 componentWillReceiveProps(newProps, newState){
   console.log('[App] Component WILL RECEIVE PROPS')
   console.log('nextProps',newProps)
  console.log('nextState',newState,this.state.data)
 }
//  static getDerivedStateFromProps(props, statess) {
//   console.log('[App] GETDERIVEDSTATEFROMPROPS')
//   console.log('props',props)
// //  console.log('state',statess,this.state.data)   
  
// }

 componentWillUpdate(nextProps, nextState) {
    console.log('[App] Component WILL UPDATE!');
    console.log('nextProps',nextProps)
    console.log('nextState',nextState,this.state.data)
 }
 componentDidUpdate(prevProps, prevState) {
    console.log('[App] Component DID UPDATE!')
 }
 componentWillUnmount() {
    console.log('[App] Component WILL UNMOUNT!')
 }
   render() {
     console.log('[App] rendering component')
      return (
         <div>
            <button onClick = {this.setNewNumber}>INCREMENT</button>
            <Content myNumber = {this.state.data}></Content>
            {/* <h2>{this.state.data}</h2> */}
         </div>
      );
   }
}

export default App;