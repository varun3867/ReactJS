const http2 = require ("http2")
const fs = require("fs")
// const openssl = require('openssl-nodejs')
const node_openssl = require('node-openssl-cert');
const openssl1 = new node_openssl();

// const node_openssl = require('node-openssl-cert');
// var options = {
//     binpath: 'C:/Users/chinnapapakka.reddy/Downloads/openssl-1.1.0h-x64-VC201712/openssl-1.1.0h-x64-VC2017/openssl.exe'
// }
// const openssl = new node_openssl(options);



// console.log(process.env)
// const http2 = require('http2');
session.on('stream', (stream, headers, flags) => {
  const method = headers[':method'];
  const path = headers[':path'];
  // ...
  stream.respond({
    ':status': 200,
    'content-type': 'text/plain; charset=utf-8'
  });
  stream.write('hello ');
  stream.end('world');
});
// openssl('openssl req -config csr.cnf -x509 -sha256 -nodes -days 365 -newkey rsa:2048 -keyout key.key -out certificate.crt')
// openssl("openssl req -x509 -newkey rsa:4096 -nodes -sha256 -subj '/CN=localhost' -keyout private.pem -out cert.pem")
const server = http2.createSecureServer({
    "key":"",
    // fs.readFileSync("localhost-private.pem"),
    "cert": ""
    // fs.readFileSync("localhost-cert.pem")
})

server.on("stream", (stream, headers) => {
    console.log(stream.id);
    stream.respond({
        "content-type": "application/json",
        "status": 200
    })

    stream.end(JSON.stringify({
        "user": "Domnic",
        "id": 21
    }))
})


server.listen(8081);
console.log("listening on port 8081");