import React,{Component} from 'react';
import classes from './App.module.css';

class App extends Component {
  state={
    draggables:[],
    containers:[],
    itemto:"",
    itemDragged:"",
    print:""
  }
  clickHandler = ()=>{
    //console.log('clickHandler.....')
    this.state.draggables.forEach(draggable => {
      draggable.addEventListener('dragstart', () => {
        //console.log('draggable',draggable)
        draggable.classList.add('draggedElement')
      })
    
      draggable.addEventListener('dragend', () => {
        // console.log("DRAG END NOWWWWW... ")
        let print = this.state.itemDragged +" is moving to "+this.state.itemto
        this.setState({print:print})
        console.log(print)
        draggable.classList.remove('draggedElement')
      })
    })
    // //console.log('state contaimers are : ',this.state.containers)
    // this.state.containers.forEach
    Object.values(this.state.containers).map(container => {
      //console.log('entered into container',container)
      container.addEventListener('dragover', e => {
        //console.log('entered into addEventListener')
        e.preventDefault()
        // //console.log('event : jjjjjjj',e)
        //console.log("DRAGOVER CONTAINER IS : ",container)
        let c = container.outerHTML
        let box = c.substring(9,13)
        this.setState({itemto:box})
        //console.log('the item moving to box : : ',c.substring(9,13))

        // this.setState({itemto:container},()=>//console.log("itemto is :",typeof(this.state.itemto)))
        const nextElement = getDragAfterElement(container, e.clientX)
        //console.log('afterElement is : ',nextElement)
        let draggedElement = document.querySelector('[class*=draggedElement]')
        //console.log('draggable is last one [CSP]: ',draggedElement,typeof(draggedElement))
        let dragItemString="";
        let dragItem=""
        if(draggedElement!=null){
        dragItemString=  draggedElement.outerHTML
        
        if(dragItemString.includes('Item-1')){
          dragItem="Item-1"
        }
        else if(dragItemString.includes('Item-2')){
          dragItem="Item-2"
        }
        else if(dragItemString.includes('Item-3')){
          dragItem="Item-3"
        }
        else if(dragItemString.includes('Item-4')){
          dragItem="Item-4"
      }
        else if(dragItemString.includes('Item-5')){
           dragItem="Item-5"
        }
          //console.log("draggedddddddddddd is :: ",dragItem)
          this.setState({itemDragged:dragItem})
        }
       
        if (nextElement === null) {
          container.appendChild(draggedElement)
        } else if(nextElement!==null && draggedElement !==null){
          container.insertBefore(draggedElement, nextElement)
        }else{
          // //console.log('entered into here')
        }
      })
    })

 
     
    const getDragAfterElement = (container, x) => {
      //console.log('entered into getDragAfterElement',container)
      // const draggableElements = [...container.querySelectorAll('.draggable:not(.dragging)')]
      const draggableElements = [...container.querySelectorAll('[class*=draggable]:not(.dragging)')]
    //console.log('elementsDraggable',draggableElements)
      return draggableElements.reduce((nearest, boxIndexes) => {
        const itemBox = boxIndexes.getBoundingClientRect()
        // //console.log('box',itemBox)
        // //console.log('y',x)
        // //console.log('box top is : ',itemBox.top)
        // //console.log('box height is : ',itemBox.height)


        const itemToBePlaced = x - itemBox.left - itemBox.width / 2
        // //console.log('offset',itemToBePlaced)
        if (itemToBePlaced < 0 && itemToBePlaced > nearest.itemToBePlaced) {
          return { itemToBePlaced: itemToBePlaced, element: boxIndexes }
        } else {
          return nearest
        }
      }, { itemToBePlaced: Number.NEGATIVE_INFINITY }).element
    }

  }

  shouldComponentUpdate(newProps, newState) {
    // console.log('[App] Component SHOULD UPDATE!');
    // console.log('nextState',newState,this.state.data)
    if(newState==this.state){
      return false;
    }
    else{
      return true
    }
   }

  
  componentDidMount(){
    //console.log('[App] componentDidMount')
    const draggables = document.querySelectorAll("[class*=draggable]")
    // //console.log('draggables : ',draggables)
    this.setState({draggables:draggables},()=>{
      // //console.log('draggables in state',this.state.draggables)
    })
    const containers = document.querySelectorAll('[class*=container]')
    this.setState({containers:containers},()=>{
      // //console.log('containers in state',this.state.containers)
    })
        // //console.log('containers in did mount : ',containers)


  }
  render(){
    // //console.log('render() [App]')
    var c = document.getElementById("box1")
    // let print = this.state.itemDragged +" is moving to "+this.state.itemto
    // console.log(print)

    // //console.log("box1 contains : ",c)
  return (
    <div className={classes.DragDrop}>
       <div id="box1" className={classes.container}>
    <p className={classes.draggable} draggable="true" onDragStart={this.clickHandler}>Item-1</p>
    <p className={classes.draggable} draggable="true" onDragStart={this.clickHandler}>Item-2</p>
    <p className={classes.draggable} draggable="true" onDragStart={this.clickHandler}>Item-5</p>
    {/* <p className={classes.draggable} draggable="true" onDragStart={this.clickHandler}>Item-6</p>
    <p className={classes.draggable} draggable="true" onDragStart={this.clickHandler}>Item-7</p> */}
  </div>
  <div id="box2" className={classes.container}>
    <p className={classes.draggable} draggable="true" onDragStart={this.clickHandler}>Item-3</p>
    <p className={classes.draggable} draggable="true" onDragStart={this.clickHandler}>Item-4</p>
  </div>
  </div>

  )}
}

export default App;
