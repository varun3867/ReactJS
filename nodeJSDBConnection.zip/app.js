var express = require('express')
  , app = express()

var db = require('./db')


app.use( (request, response, next) => {
    console.log("app.use function...")
    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  });

db.connect('mongodb://localhost:27017/', function(err) {
  if (err) {
    console.log('Unable to connect to Mongo.')
    process.exit(1)
  } else {
    app.listen(3000, function() {
      console.log('Listening on port 3000...')
    })
  }
})

app.get("/",(req,res)=>{
    console.log("came into "/" of app.get")
    var c = db.get().collection('Resource').find({}).toArray(function(err, result) {
        res.send(result)
   });
})