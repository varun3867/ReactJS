var http = require('http');
var express=require('express');
var app=express();


app.use( (request, response, next) => {
    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  });

app.get('/',(req,res)=>{
    res.send("Hello world");
});
var server=app.listen(3000,()=>{
    console.log("Server running on port 3000");
});




// app = http.createServer((req,res)=>{
//     console.log("creating server");
//     res.write("welcome here");
//     res.end();
// }).listen(8006)

